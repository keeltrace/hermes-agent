# Hermes-Jev

**Give Hermes a System One.**

Hermes is excellent at open-ended reasoning, planning, coding, browsing, and tool use. A large fraction of autonomous-agent control flow is not open-ended generation, though. It is bounded decisions: which tool, which worker, whether a result passed, whether to retry, whether an action needs approval, and whether confidence is high enough to continue.

Hermes-Jev turns [TypeSafe Jev](https://typesafe.ai/) into that decision layer for [Hermes Agent](https://github.com/NousResearch/hermes-agent).

> Community project. Not affiliated with or endorsed by TypeSafe AI or Nous Research.

## Why this repo exists

Existing early Jev/Hermes experiments focus on one task such as skill routing or smart approvals. Hermes-Jev is intentionally broader: a reusable **DecisionContract runtime** with typed decisions, ranking, verification, privacy-aware receipts, and an opt-in Hermes lifecycle gate.

```text
             Hermes / System 2
       reason · plan · code · create
                   |
                   v
          Hermes-Jev / System One
       decide · rank · verify · gate
                   |
                   v
     execute · retry · replan · human
```

## v0.1.0 surface

### `jev_decide`
Choose exactly one label from an explicit allowed set and return the full probability distribution.

### `jev_rank`
Use the same Choice probabilities to rank a bounded candidate set for routing and prioritization.

### `jev_verify`
Return exactly one of `PASS | RETRY | REPLAN | ESCALATE` after an execution attempt.

### Optional `pre_tool_call` gate
Hermes-Jev can evaluate proposed tool calls before execution.

- `off` (default): no automatic Jev call.
- `advisory`: evaluate + receipt, never alter execution.
- `enforce`: high-confidence `BLOCK` blocks; `APPROVAL` or low confidence routes to Hermes human approval.
- provider failure in `enforce` mode **fails to human approval**, not silent execution.

The gate is intentionally opt-in because tool arguments may contain sensitive data.

## Install

Until the standalone GitHub repo is published, install from a local checkout:

```bash
hermes plugins install /path/to/hermes-jev --no-enable
hermes plugins enable hermes-jev
```

Set your TypeSafe key through Hermes' normal plugin environment flow or your environment:

```bash
export TYPESAFE_API_KEY='...'
```

Then verify the plugin with Hermes' real loader:

```bash
hermes plugins doctor /path/to/hermes-jev --ci
```

Once cataloged, the intended install path is:

```bash
hermes plugins install jev
```

## Automatic gate

Default is **off**.

```bash
export HERMES_JEV_GATE_MODE=advisory
# or, after evaluating it on your own traffic:
export HERMES_JEV_GATE_MODE=enforce
```

Optional confidence threshold:

```bash
export HERMES_JEV_MIN_CONFIDENCE=0.85
```

Hermes-Jev never treats typed output as proof of correctness. A valid label can still be the wrong label. Low confidence is routed toward human review.

## Privacy

Before any tool-call state is sent to Jev, Hermes-Jev recursively redacts common secret-bearing keys and common bearer/API-token patterns.

Receipts default to **hash-only state**:

```json
{
  "schema": "hermes-jev-receipt/v1",
  "contract": "hermes/pre-tool-gate/v1",
  "state_sha256": "...",
  "model": "jev-latest",
  "latency_ms": 123.4,
  "result": {"value": "APPROVAL", "confidence": 0.88}
}
```

Set `HERMES_JEV_RECEIPT_DETAIL=sanitized` only when you explicitly want sanitized state persisted for replay/evaluation.

Default receipt path:

```text
$HERMES_HOME/jev/receipts.jsonl
```

## Wire compatibility

The built-in client follows TypeSafe's current public System One wire shape:

- `POST /v1/systemone`
- `Authorization: Bearer <key>`
- default model `jev-latest`
- questions use the public `choice`, `noul`, and `score` schema shape

The DecisionEngine is provider-independent by design. Jev is the flagship backend, while contracts and receipts are ours.

## Decision contracts

A contract names a stable semantic boundary rather than an API call. v0.1 ships:

- `hermes/pre-tool-gate/v1`
- `rank/v1`
- `verify/v1`

The next release will add versioned external contract loading, policy compilation, and replay comparisons across model/provider versions.

## Testing

No TypeSafe key is required for the unit suite:

```bash
python -m unittest discover -s tests -v
python -m compileall -q .
```

A live Jev smoke/eval requires `TYPESAFE_API_KEY` and is deliberately separate from offline tests.

## What is deliberately NOT claimed yet

- No live Jev benchmark has been run from this build environment.
- No claim that Jev decisions are always correct.
- No claim that the automatic gate is production-safe for every tool set.
- No claim of official TypeSafe or Nous support.

The first public benchmark should ship raw corpus/evidence, not marketing numbers.

## Roadmap

See [ROADMAP.md](ROADMAP.md). The short version: own the generic decision runtime, then add replay/evals, decision recipes, model/skill/worker routing, dashboard observability, and provider adapters while keeping the Hermes integration external to core.

## License

MIT.
